<template>
  <h2>Unit Selection</h2>
</template>

<script>
export default {
  name: 'AdminUnitSelection',
}
</script>

<template>
  <h2>Acquire Unit</h2>
</template>

<script>
export default {
  name: 'AdminAcquireUnit',
}
</script>

<template>
  <div>Admin Dashboard</div>
</template>

<script>
export default {
  name: 'AdminDashboard',
}
</script>
